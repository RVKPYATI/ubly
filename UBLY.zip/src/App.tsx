import { Route, Routes } from "react-router";
import { Login } from "./components/Login/Login";
import { Register } from "./components/Register/Register";
import { Menu } from "./components/Menu";

function App() {
  return (
    <>
      <div className="font-rubik">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Routes>
        <div className="flex">
          <Menu />
          <div className="w-full h-screen bg-dark"></div>
        </div>
      </div>
    </>
  );
}

export default App;
